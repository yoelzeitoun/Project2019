﻿using System;

namespace Project01_2626_8634_dotNet5780
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
