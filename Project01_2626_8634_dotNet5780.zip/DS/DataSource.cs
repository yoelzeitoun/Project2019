﻿using System;
using System.Collections;
using System.Collections.Generic;
using BE;

namespace DS
{
    public class DataSource
    {
        public static List<GuestRequest> guestRequestList = new List<GuestRequest>();
        public static List<HostingUnit> hostingUnitList = new List<HostingUnit>();
        public static List<Order> orderList = new List<Order>();
    }
}
