﻿public enum Type{Zimmer, Guest_room, Hotel_room, Tent}
public enum Area { All, North, South, Central, Jerusalem }
public enum Status_order { In_progress, Email_sent, Closed_for_customer_unresponsiveness, Closed_for_customer_response, Closed_for_another_order }
public enum Status_client { Active, Closed_through_site, Closed_expiration }
public enum Pool { Yes,No,Option}
public enum Jaccuzzi { Yes, No, Option }
public enum Garden { Yes, No, Option }
public enum ChildrensAttractions { Yes, No, Option }

